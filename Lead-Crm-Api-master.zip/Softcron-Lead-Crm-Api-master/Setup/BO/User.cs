﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Setup.BO
{
    public class User
    {
    }
   
    public class AddClientUserResponse
    {
        public int UserID { get; set; }
    }

    public class ChangePasswordResponse { 
    }

}
