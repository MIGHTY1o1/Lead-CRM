﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Setup.BO
{
    public class TableOperationResponse
    {
        public int LastInsertedID { get; set; }
    }
}
