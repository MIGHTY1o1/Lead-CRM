﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Setup.BO
{
    public class ExtensionDBMaster
    {
    }
    public class TableResponse
    {
       
    }
    public class ColumnResponse
    {
        public int ExtensionFieldID { get; set; }
    }
    
}
