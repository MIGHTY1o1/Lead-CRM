﻿using System;

namespace Setup
{
    public class Class1
    {
    }
}
